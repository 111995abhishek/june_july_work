# FeedbackR - Client

This is the React-redux based front end of the application.

use `npm install` to start. Refer to the main README.md at the root level for detailed getting started instructions.