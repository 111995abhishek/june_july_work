import React from 'react';

const Landing = () => {
  return (
    <div style={{ textAlign: 'center' }}>
      <h1>
        FeedbackR!
      </h1>
      Collect feedback that matter!
    </div>
  );
};

export default Landing;
