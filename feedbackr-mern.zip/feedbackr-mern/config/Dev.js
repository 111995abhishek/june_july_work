module.exports = {
    googleClientID:
      '658814934905-2sf7hum6r965msf6qig8g58hvgpau89q.apps.googleusercontent.com',
    googleClientSecret: 'sON1ddvlpF6y7bPLrn8NDxW4',
    // mongoURI:
    //   'mongodb+srv://abhishekUser:RuKx1lvXrOz1xCo4@cluster0.weyc0.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
      cookieKey: 'aks95',
      stripePublishableKey: 'pk_test_51J2V0zSIGR09SisRuJ3HCU2IECDdDlmfgWkox7MK2kHeqcQdKBpFqibYaW6UJE9KpJIpjvCSjehPRfArSl5oTrBK00VzeEhHgd',
      stripeSecretKey:'sk_test_51J2V0zSIGR09SisRYosvIx1qtqx54lTPrcZC6ZAEDacfpTmjC4sat5IzuJI1bhghd30XhdCBQf2cSsUkiWA9q4kB00zwwF3bct',
      sendGridKey:'<Your sendgrid key>',
      redirectDomain: 'http://localhost:3000'
  };